USE NexusTmp;

GO
	CREATE TABLE UserInputtedData (
		DataID INT PRIMARY KEY,
		LastModified DATE,
		DateOfCreation DATE
	);