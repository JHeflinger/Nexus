CREATE DATABASE NexusTmp ON PRIMARY(
   NAME = 'NexusTmp',
   FILENAME = 'D:\Database\MSSQL15.MSSQLSERVER\MSSQL\DATA\NexusTmp.mdf',
   SIZE = 600MB,
   MAXSIZE = 3000MB,
   FILEGROWTH = 12 %
) LOG ON(
   NAME = 'NexusTmp_log',
   FILENAME = 'D:\Database\MSSQL15.MSSQLSERVER\MSSQL\DATA\NexusTmp_log.ldf',
   SIZE = 300MB,
   MAXSIZE = 2200MB,
   FILEGROWTH = 17 %
);