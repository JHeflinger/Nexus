USE NexusTmp;

GO
    CREATE TABLE Category (
        CategoryID INT PRIMARY KEY,
        CategoryName VARCHAR(20),
        Description VARCHAR(200)
    );